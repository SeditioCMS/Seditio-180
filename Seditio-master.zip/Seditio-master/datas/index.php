<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org
[BEGIN_SED]
File=datas/index.php
Version=180
Updated=2025-jan-25
Type=Core
Author=Seditio Team
Description=Directory blocker
[END_SED]
==================== */

/* ==== Directory blocker ==== */
