/*-------------------------------------------------------
*
*   Copyright (c) 2011-2022, Seditio Team
*   Copyright (c) 2001-2011, Neocrome
*
*--------------------------------------------------------*/

Seditio 178

INSTALLATION

1. Copy all files of the engine in the root directory or subdirectory

2. Make the following folders and all their subfolders writable too
  with CHMOD 777 or CHMOD 775:

/datas/avatars
/datas/defaultav
/datas/photos
/datas/thumbs
/datas/resized
/datas/signatures
/datas/users

3. Arrive at http://your_site/install

4. Follow the instructions of the installer.

CONFIGURATION AND CUSTOMIZATION ENGINE

Settings are in the file /datas/config.php

For all questions, please visit Seditio Team http://seditio.org