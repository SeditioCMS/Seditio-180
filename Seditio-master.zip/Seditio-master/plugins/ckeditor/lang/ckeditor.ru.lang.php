<?php

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/ckeditor/lang/ckeditor.ru.lang.php
Version=180
Updated=2012-оct-19
Type=Plugin
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['cfg_ckeditor_skin'] =  array("Скин по-умолчанию", "");
$L['cfg_ckeditor_lang'] =  array("Язык интерфеса редактора", "");
$L['cfg_ckeditor_color_toolbar'] =  array("Цвет тулбара", "");
$L['cfg_ckeditor_other_textarea'] =  array("Использовать редактор для всех текстовых полей", "");
$L['cfg_ckeditor_other_toolbar'] =  array("Тулбар для других текстовых полей", "");
$L['cfg_newpagetext'] =  array("Тулбар для режима добавления страниц", "");
$L['cfg_rpagetext'] =  array("Тулбар для режима редактирования страниц", "");
$L['cfg_newpmtext'] =  array("Тулбар для личных сообщений", "");
$L['cfg_rusertext'] =  array("Тулбар для подписи пользователя", "");
$L['cfg_rtext'] =  array("Тулбар для комментариев", "");
$L['cfg_newmsg'] =  array("Тулбар для форума", "");
$L['cfg_newpagetext_height'] =  array("Высота текстового поля для режима добавления страниц", "");
$L['cfg_rpagetext_height'] =  array("Высота текстового поля для режима редактирования страниц", "");
$L['cfg_newpmtext_height'] =  array("Высота текстового поля для личных сообщений", "");
$L['cfg_rusertext_height'] =  array("Высота текстового поля для подписи пользователя", "");
$L['cfg_rtext_height'] =  array("Высота текстового поля для комментариев", "");
$L['cfg_newmsg_height'] =  array("Высота текстового поля для форума", "");
$L['cfg_ckeditor_other_height'] =  array("Высота для других текстовых полей", "");
$L['cfg_ckeditor_global_toolbar'] =  array("Глобальный тулбар для группы ", "");
$L['cfg_ckeditor_detectlang'] =  array("Определять язык интерфейса редактора из профиля пользователя", "");
