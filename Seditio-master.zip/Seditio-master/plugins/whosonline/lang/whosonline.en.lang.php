<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org
[BEGIN_SED]
File=plugins/whosonline/lang/whosonline.en.lang.php
Version=180
Updated=2025-jan-25
Type=
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['plu_title'] = "Who's online ?";
$L['plu_mostonline'] = "Most users ever online was ";
$L['plu_therescurrently'] = "There's currently ";
$L['plu_visitors'] = " visitor(s) and ";
$L['plu_members'] = " registered member(s) online.";
$L['plu_lastseen1'] = "Last seen";
$L['plu_in'] = "in";
$L['plu_visitor'] = "Visitor";
