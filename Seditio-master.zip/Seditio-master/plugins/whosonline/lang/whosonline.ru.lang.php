<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/whosonline/lang/whosonline.ru.lang.php
Version=180
Updated=2025-jan-25
Type=
Author=Seditio Team (Translated - Antar)
Description=
[END_SED]
==================== */

$L['plu_title'] = "Кто онлайн ?";
$L['plu_mostonline'] = "Максимальное число пользователей на сайте: ";
$L['plu_therescurrently'] = "Сейчас на сайте ";
$L['plu_visitors'] = " гостей и ";
$L['plu_members'] = " зарегистрированных пользователей:";
$L['plu_lastseen1'] = "Последний раз был замечен";
$L['plu_lastseen2'] = "секунд(ы) назад";
$L['plu_in'] = "посетив";
$L['plu_visitor'] = "Гость";
