<?php

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/recentitems/lang/recentitems.ru.lang.php
Version=180
Updated=2025-jan-25
Type=Plugin
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['cfg_maxpages'] = array("Количество страниц для отображения", "");
$L['cfg_maxtopics'] = array("Количество топиков для отображения", "");
$L['cfg_maxpolls'] = array("Количество опросов для отображения", "");
