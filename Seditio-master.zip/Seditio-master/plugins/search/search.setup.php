<?PHP

/* ====================
[BEGIN_SED]
File=plugins/search/search.setup.php
Version=180
Date=2010-feb-05
Type=Plugin
Author=Seditio Team
Description=
[END_SED]

[BEGIN_SED_EXTPLUGIN]
Code=search
Name=Search
Description=Search for words in pages and forums
Version=180
Date=2008-jun-04
Author=Seditio Team
Copyright=
Notes=
SQL=
Auth_guests=R
Lock_guests=W12345A
Auth_members=R
Lock_members=W12345A
[END_SED_EXTPLUGIN]
==================== */
