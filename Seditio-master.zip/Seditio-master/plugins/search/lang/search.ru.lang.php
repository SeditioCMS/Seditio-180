<?PHP

/* ====================
[BEGIN_SED]
File=plugins/search/lang/search.ru.lang.php
Version=180
Updated=2025-jan-25
Type=
Author=Seditio Team, Translated by Amro - http://seditio.org
Description=
[END_SED]
==================== */

$L['plu_title'] = "Поиск";

$L['plu_searchin'] = "<strong>Ключевое слово (а)</strong>";

$L['plu_querytooshort'] = "Поисковый запрос слишком короткий !";
$L['plu_toomanywords'] = "Слишком много слов, ограничение - ";
$L['plu_found'] = "Найдено";
$L['plu_match'] = "совпадений";

$L['plu_nofound'] = "Совпадений не найдено";

$L['plu_allsections'] = "Все секции";
$L['plu_allcategories'] = "Все категории";
