<?PHP

/* ====================
[BEGIN_SED]
File=plugins/search/lang/search.en.lang.php
Version=180
Updated=2025-jan-25
Type=
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['plu_title'] = "Search";

$L['plu_searchin'] = "<strong>Keyword(s)</strong>";

$L['plu_querytooshort'] = "The query string is too short !";
$L['plu_toomanywords'] = "Too many words, limit is set to";
$L['plu_found'] = "Found";
$L['plu_match'] = "match(es)";

$L['plu_nofound'] = "Matches not found";

$L['plu_allsections'] = "All sections";
$L['plu_allcategories'] = "All categories";
