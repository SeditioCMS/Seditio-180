<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/syntaxhighlight//lang/syntaxhighlight.ru.lang.php
Version=180
Updated=2012-feb-16
Type=Plugin
Author=Amro
Description=
[END_SED]

==================== */

$L['cfg_syntaxhighlight_theme'] = array("Цветовая тема Syntaxhighlight", "");

?>