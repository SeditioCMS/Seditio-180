<?php

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/jevix/lang/jevix.ru.lang.php
Version=180
Updated=2025-jan-25
Type=Plugin
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['cfg_use_xhtml'] = array("Использовать XHTML ?", "");
$L['cfg_use_for_admin'] = array("Включить Jevix для администраторов", "");
