<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Russian Seditio Team 
http://www.neocrome.net http://ldu.ru

[BEGIN_SED]
File=plugins/sedcaptcha/lang/sedcaptcha.ru.lang.php
Version=180
Updated=2025-jan-25
Type=Plugin
Author=Amro
Description=Plugin to protect the registration process with a Cool PHP Captcha.
[END_SED]
==================== */

$L['plu_verification_failed'] = "Неверно введено проверочное слово";
$L['plu_scaptcha_noties'] = "Не можете прочитать?";
