<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/skineditor/skineditor.setup.php
Version=180
Updated=2022-jul-26
Type=Plugin
Author=Seditio Team
Description=
[END_SED]

[BEGIN_SED_EXTPLUGIN]
Code=skineditor
Name=Skin editor
Description=Manage your templates files online
Version=180
Date=2022-jul-26
Author=Seditio Team
Copyright=
Notes=
SQL=
Auth_guests=RW
Lock_guests=12345A
Auth_members=RW
Lock_members=12345A
[END_SED_EXTPLUGIN]

==================== */

if (!defined('SED_CODE')) {
    die('Wrong URL.');
}
