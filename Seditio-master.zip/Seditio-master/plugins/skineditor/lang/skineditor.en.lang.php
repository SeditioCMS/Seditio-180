<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org
[BEGIN_SED]
File=plugins/lang/skineditor.en.lang.php
Version=180
Updated=2025-jan-25
Type=
Author=Seditio Team
Description=
[END_SED]
==================== */


$L['plu_makbak'] = "Backup now";
$L['plu_delbak'] = "Delete the backup";
$L['plu_resbak'] = "Restore the backup";
$L['plu_reopen'] = "Update and come back here";
