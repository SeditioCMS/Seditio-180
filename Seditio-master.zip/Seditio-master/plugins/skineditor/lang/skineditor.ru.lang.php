<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org
[BEGIN_SED]
File=plugins/lang/skineditor.ru.lang.php
Version=180
Updated=2025-jan-25
Type=
Author=Seditio Team
Description=
[END_SED]
==================== */


$L['plu_makbak'] = "Сделать бэкап";
$L['plu_delbak'] = "Удалить бэкап";
$L['plu_resbak'] = "Восстановить из бэкапа";
$L['plu_reopen'] = "Обновить и вернутся обратно";
