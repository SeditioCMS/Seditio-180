<?php

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/news/lang/news.ru.lang.php
Version=180
Updated=2025-jan-25
Type=Plugin
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['cfg_category'] = array("Код родительской категории", "");
$L['cfg_maxpages'] = array("Количество отображаемых страниц", "");
