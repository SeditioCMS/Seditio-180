<?php

/* ====================
Seditio - Website engine
Copyright Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/uploader/lang/uploader.en.lang.php
Version=180
Updated=2025-jan-25
Type=Plugin
Author=Seditio Team
Description=
[END_SED]
==================== */

$L['upl_mainimage'] = "Default";
$L['upl_upload_images'] = "Upload images";
$L['upl_choose_from_pfs'] = "Choose from PFS";

?>