<?PHP

/* ====================
Seditio - Website engine
Copyright Neocrome & Seditio Team
https://seditio.org

[BEGIN_SED]
File=plugins/sednews/lang/sednews.ru.lang.php
Version=180
Updated=2025-jan-25
Type=Plugin
Author=Seditio Team
Description=
[END_SED]
==================== */

if (!defined('SED_CODE')) {
    die('Wrong URL.');
}

$L['sednews_title'] = "Новости Seditio";

$L['cfg_rssfeed'] = array("URL адрес новостного RSS фида", "");
$L['cfg_maxitems'] = array("Количество отображаемых записей", "");
